const express = require("express");
const cors = require("cors");
const mysql = require("mysql");
const app = express();
const PORT = 3001;
const fs = require('fs');
const path = require('path');

const db = mysql.createPool({
    host: "192.168.0.37",
    user: "csy",
    password: "csy",
    database: "fr",
});

app.use(cors());

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/static', express.static(path.join(__dirname, 'signature')));

app.use('/static', express.static('http://192.168.0.57:3001/react/sign/server/'));
app.listen(PORT, () => {
    console.log(`서버가 포트 ${PORT}에서 실행 중입니다.`);
});


app.get('/signature/:fileName', (req, res) => {
    const { fileName } = req.params;
    const imagePath = path.join(signatureDir, fileName);
    console.log(imagePath);
    fs.readFile(imagePath, (err, data) => {
        if (err) {
            console.error('서명 이미지를 읽는 중 에러:', err);
            res.status(500).send('서명 이미지를 읽는 중 에러');
        } else {
            res.writeHead(200, { 'Content-Type': 'image/png' });
            res.end(data);
        }
    });
});


app.get('/', (req, res) => {
    res.header('Access-Control-sAllow-Origin', '*');

    // 서명 데이터 중 가장 최근 데이터 1개만 가져오도록 쿼리 수정
    const sqlQuery = 'SELECT signatureData FROM signature ORDER BY created_at DESC LIMIT 1';

    db.query(sqlQuery, (err, result) => {
        if (err) {
            console.error('서명 정보를 가져오는 중 에러 발생:', err);
            res.status(500).send('서명 정보를 가져오는 중 에러 발생');
        } else {
            if (result.length > 0) {
                console.log(result[0].signatureData);
                const signatureData = result[0].signatureData;
                console.log("서명 이미지 데이터:", signatureData);
                res.send({ signatureData });
            } else {
                // 서명 데이터가 없을 경우 빈 데이터를 보내줄 수 있습니다.
                res.send({ message: "서명 데이터가 없습니다." });
            }
        }
    });
});
// 서명 데이터를 저장할 디렉토리 경로 설정
const signatureDir = path.join(__dirname, 'signature');
if (!fs.existsSync(signatureDir)) {
    fs.mkdirSync(signatureDir);
}

app.post('/saveSignature', (req, res) => {
    const signatureData = req.body.signatureData; // 클라이언트로부터 받은 Base64로 인코딩된 이미지 데이터
    const imageBuffer = Buffer.from(signatureData.split(',')[1], 'base64');

    // 파일 이름 생성 (유니크한 이름으로 저장하는 것이 좋음)
    const fileName = `${Date.now()}.png`;

    // 파일 시스템에 이미지 저장
    fs.writeFile(path.join(signatureDir, fileName), imageBuffer, (err) => {
        if (err) {
            console.error('Error saving signature:', err);
            res.status(500).json({ success: false, error: 'Failed to save signature' });
        } else {
            // 파일이 성공적으로 저장되었을 때, 파일 경로를 데이터베이스에 저장
            const imagePath = `/signature/${fileName}`;

            const sql = 'INSERT INTO signature (signatureData) VALUES (?)';
            db.query(sql, [imagePath], (err, result) => {
                if (err) {
                    console.error('서명 실패:', err);
                    res.status(500).json({ success: false, error: 'Failed to save signature' });
                } else {
                    console.log('서명이 성공적으로 저장되었습니다.');
                    res.json({ success: true });
                }
            });
        }
    });
});