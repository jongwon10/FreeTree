import React, { useRef } from 'react';
import SignatureCanvas from 'react-signature-canvas';
import axios from 'axios';

const Company = () => {
    const signatureRef = useRef(null);

    const saveSignatureToDatabase = () => {
        if (signatureRef.current) {
            const signatureData = signatureRef.current.toDataURL(); // 이미지 데이터를 Base64 형식으로 얻기
            axios.post('http://192.168.0.57:3001/saveSignature', { signatureData })
                .then(response => {
                    console.log('서명이 성공적으로 저장되었습니다.');
                })
                .catch(error => {
                    console.error('서명 저장 실패:', error);
                });
        }
    };
    const handleSaveSignature = () => {
        if (signatureRef.current) {
            const signatureData = signatureRef.current.toDataURL();
            saveSignatureToDatabase(signatureData);
        }
    };
    const handleClearSignature = () => {
        signatureRef.current.clear();
    };
    return (
        <div>
            <SignatureCanvas
                ref={signatureRef}
                penColor="black"
                canvasProps={{
                    width: 400,
                    height: 200,
                    className: 'sigCanvas',
                    style: { border: '1px solid #ccc', background: '#f7f7f7' },
                }}
            />
            <button onClick={handleSaveSignature}>사업체 서명 저장</button>
            <button onClick={handleClearSignature}>사업체 서명 지우기</button>
        </div>
    );
};

export default Company;
