import React from 'react';
import {BrowserRouter as Router, Route, Link, Routes} from 'react-router-dom';

import Company from './Company';
import ContractPDF from './ContractPDF';
import Contract from './Contract';
function App() {
    return (
        <Router>
            <Routes>
             {/*   <Route path="/ContractPDF" element={<ContractPDF />} />*/}
                <Route path="/" element={<Contract />} />
               {/* <Route path="/" element={<Company />} />*/}
            </Routes>
        </Router>
    );
}

export default App;
